# KyoStore — starter dengan halaman terpisah

## Isi
- `index.html`: toko publik/pembeli
- `login/index.html`: tampilan awal login
- `admin/index.html`: halaman admin placeholder yang tidak menyediakan aksi edit sebelum autentikasi dikonfigurasi
- `supabase-setup.sql`: skema awal yang dapat ditinjau di Supabase SQL Editor

## Deploy ke Vercel
1. Upload/commit seluruh isi folder ini ke root repository GitHub yang tersambung ke Vercel.
2. Pastikan `index.html` ada di root repository, bukan di dalam folder tambahan.
3. Commit perubahan dan tunggu deployment Vercel.
4. URL pembeli: `/`
5. URL login: `/login/`
6. URL admin: `/admin/`

## Penting
Ini adalah starter UI, bukan sistem transaksi produksi. Login Google/email belum dikonfigurasi. Admin belum bisa mengubah produk; hal itu disengaja sampai otorisasi server/database benar-benar dipasang. Produk awal di toko hanya contoh lokal dan tidak tersinkron otomatis dengan admin. Jangan menerima uang sungguhan sebelum Supabase Auth, RLS, backend transaksi, dan webhook payment gateway diimplementasikan serta diuji.
