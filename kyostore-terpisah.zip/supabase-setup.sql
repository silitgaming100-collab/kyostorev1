-- KyoStore starter schema. Review before running in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'buyer' check (role in ('buyer','owner')),
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'Umum',
  price bigint not null check (price >= 0),
  icon text not null default '✦',
  image_url text,
  description text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.products enable row level security;
create policy "Users can read own profile" on public.profiles
for select to authenticated using (id = auth.uid());
create policy "Anyone can read active products" on public.products
for select to anon, authenticated using (active = true);
-- Intentionally do not add client-side insert/update/delete policies.
-- Owner writes must be implemented only after a trusted owner-role check and appropriate RLS policies.
-- Never put the Supabase service_role key in HTML or client-side JavaScript.
